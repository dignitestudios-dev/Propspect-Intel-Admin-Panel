export const loginValues = {
  email: "",
  password: "",
};
